setwd("C:\\Users\\it24101461\\Desktop\\LabSheet06")

#Exercise 
# Part 1
# Q1
# Binominal Distribution
# X=the number of students who passed the test

# Part 1
# Q2
1- pbinom(46,50,0.85,lower.tail = FALSE)

# Part 3
# Q3
dpois(15,12)

