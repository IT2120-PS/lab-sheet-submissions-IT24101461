#1

setwd("C://Users/it24101461/Desktop/IT24101461_Lab04")

branch_data <- read.table("Exercise.txt",header=TRUE,sep=",")
fix(branch_data)
attach(branch_data)

#2
class(1)
class(2)
class(3)
class(4)

#3
boxplot(Sales_X1,main="Box plot for sales",outline=TRUE,output=8,horizontal=TRUE)

#4
summary(Advertising_X2)
IQR(Advertising_X2)

#5

find_outliers <- function(Branch) {
  Q1 <- quantile(Branch, na.rm = TRUE)[2] 
  Q3 <- quantile(Branch, na.rm = TRUE)[4]
  IQR_value <- Q3 - Q1
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value  
  
  cat("Upper bound =", upper_bound, "\n")
  cat("Lower bound =", lower_bound, "\n")
  
  outliers <- Branch[Branch < lower_bound | Branch > upper_bound]
  cat("Outliers:", paste(sort(outliers), collapse = ", "), "\n")
}

find_outliers(Years_X3)
find_outliers(Branch)
